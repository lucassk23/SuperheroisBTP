sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("superheroesbtp.superheroisbtp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);